import FoodModel from "../models/foodModel.js";

// Add food item controller
const addFood = async (req, res) => {
    try {
        // Check if file was uploaded
        if (!req.file) {
            return res.status(400).json({ success: false, message: "Image is required!" });
        }

        // Create a new food item
        const food = new FoodModel({
            name: req.body.name,
            description: req.body.description,
            price: req.body.price,
            category: req.body.category,
            image: req.file.filename, // Use uploaded image filename
        });

        // Save food item to database
        await food.save();

        res.json({ success: true, message: "Food added successfully!" });

    } catch (error) {
        console.error("Error adding food:", error);
        res.status(500).json({ success: false, message: "Error adding food" });
    }
};

export { addFood };
